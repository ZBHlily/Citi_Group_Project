document.getElementById('churn-form').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent form submission

    // Get user inputs
    var creditScore = document.getElementById('credit-score').value;
    var geography = document.getElementById('geography').value;
    var gender = document.getElementById('gender').value;
    var age = document.getElementById('age').value;
    var tenure = document.getElementById('tenure').value;
    var balance = document.getElementById('balance').value;
    var numProducts = document.getElementById('num-products').value;
    var hasCrCard = document.getElementById('has-cr-card').value;
    var isActiveMember = document.getElementById('is-active-member').value;
    var estimatedSalary = document.getElementById('estimated-salary').value;

    // Make an AJAX request to the server with user inputs
    var xhr = new XMLHttpRequest();
    xhr.open('POST', '/predict', true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.onreadystatechange = function() {
        if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
            var response = JSON.parse(xhr.responseText);
            var resultText = response.prediction ? 'lost customer.' : 'retained customer.';
            document.getElementById('result-text').textContent = resultText;
            document.getElementById('result').style.display = 'block';
        }
    };

    // Send the user inputs to the server
    var requestData = JSON.stringify({
        credit_score: creditScore,
        geography: geography,
        gender: gender,
        age: age,
        tenure: tenure,
        balance: balance,
        num_of_products: numProducts,
        has_cr_card: hasCrCard,
        is_active_member: isActiveMember,
        estimated_salary: estimatedSalary
    });
    xhr.send(requestData);
});
