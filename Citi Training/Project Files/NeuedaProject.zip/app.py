from flask import Flask, render_template, request
import pandas as pd
import joblib

app = Flask(__name__)

# Load the trained model
model = joblib.load('model.pkl')

# Define the feature names
features = ['CreditScore', 'Geography', 'Gender', 'Age', 'Tenure', 'Balance', 'NumOfProducts', 'HasCrCard', 'IsActiveMember', 'EstimatedSalary']

# Function that takes user inputs and predicts customer churn
def predict_churn(credit_score=None, geography=None, gender=None, age=None, tenure=None, balance=None, num_of_products=None, has_cr_card=None, is_active_member=None, estimated_salary=None):
    # Create a DataFrame with the user inputs
    user_data = pd.DataFrame([[credit_score, geography, gender, age, tenure, balance, num_of_products, has_cr_card, is_active_member, estimated_salary]],
                             columns=features)

    # Convert categorical variables to numeric using one-hot encoding
    user_data_encoded = pd.get_dummies(user_data, drop_first=True)

    # Align the user input DataFrame with the training DataFrame to ensure matching columns
    user_data_aligned = user_data_encoded.reindex(columns=model['columns'], fill_value=0)

    # Make predictions using the trained classifier
    churn_prediction = model['model'].predict(user_data_aligned)

    return churn_prediction[0]

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        try:
            # Get form data
            credit_score = float(request.form['credit_score'])
            geography = request.form['geography']
            gender = request.form['gender']
            age = float(request.form['age'])
            tenure = float(request.form['tenure'])
            balance = float(request.form['balance']) if request.form['balance'] else None
            num_of_products = float(request.form['num_of_products'])
            has_cr_card = float(request.form['has_cr_card'])
            is_active_member = float(request.form['is_active_member'])
            estimated_salary = float(request.form['estimated_salary'])

            # Perform validation
            if balance is not None and balance < 0:
                raise ValueError("Balance must be a positive number.")
            # Add more validation checks as needed for other fields

            # Make the prediction
            prediction = predict_churn(
                credit_score, geography, gender, age, tenure, balance,
                num_of_products, has_cr_card, is_active_member, estimated_salary
            )

            # Determine the result message
            if prediction > 0:
                result = "lost customer"
            else:
                result = "retained customer"

            return render_template('index.html', prediction=result)
        except ValueError as e:
            error_message = str(e)
            print(f"Error message: {error_message}")
            return render_template('index.html', error=error_message)

    return render_template('index.html')

if __name__ == '__main__':
    app.run()
